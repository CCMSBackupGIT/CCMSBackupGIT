/*
 ============================================================================================================
 + Cerberus Content Management System
 + ---
 + - Author 		     : Gary Christopher Johnson - Rosedale, California
 + - Electronic Mail Address : TinkeSoftware@Protonmail.com
 + - Company		     : Tinke Software
 + - Company Address	     : Rosedale, California, U.S.A.
 + - Document Notes	     : View this file in a non-formatting text editor without word-wrap for the correct
 +			       display of this programming code and its indentation.
 + ---
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 +
 + ---
 + - File Location: root->Cerberus->Read_Me.txt
 + - File Version : 0.6 - Wednesday, March 1st of 2023
 + ---
 + -------------------------------------------------------------------------------
 + --()()--()()()--()()()--()()()---()()()--()()()--()--()------()()()------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()()()--()()()--()()()---()()()--()()()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()----------------
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------/-\-
 + -()-----()------()--()--()---()--()------()--()--()--()------()------------|4|-  ~ Wynn ~
 + --()()--()()()--()--()--()()()---()()()--()--()--()()()--()()()------------\-/- Build: 0.8
 ============================================================================================================
*/

================================
Installation Instructions
================================

https://www.SourceForge.net/projects/cerberuscms/Documentation
https://www.GitHub.com/TinkeSoftware/CerberusCMS_Documentation

================================
CerberusCMS on Source Forge
================================

https://www.SourceForge.net/projects/cerberuscms/

================================
CerberusCMS on Source Forge ( Demonstration Server )
================================

http://CerberusCMS.SourceForge.net

================================
CerberusCMS on Git Hub
================================

https://www.GitHub.com/TinkeSoftware/CerberusCMS

================================
CerberusCMS on Bit Bucket
================================

https://www.BitBucket.org/TinkeSoftware/CerberusCMS